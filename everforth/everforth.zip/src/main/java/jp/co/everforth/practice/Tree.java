package jp.co.everforth.practice;

import java.util.*;

public class Tree {
    private List<Leaf> topLeaves;
    private Map<String, Leaf> leaves;

    public Tree() {
        this.topLeaves = new ArrayList<>();
        this.leaves = new HashMap<>();
    }

    public boolean addTopLeaf(Leaf leaf) {
        if (topLeaves.contains(leaf)) {
            return false;
        }
        topLeaves.add(leaf);
        return true;
    }

    public boolean addLeaf(String name, Leaf leaf) {
        if (leaves.containsKey(name)) {
            return false;
        }
        leaves.put(name, leaf);
        return true;
    }

    public Leaf getLeaf(String name) {
        return leaves.get(name);
    }

    public Set<String> getNames() {
        return leaves.keySet();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Leaf top : topLeaves) {
            sb.append("+-");
            sb.append(top.getName());
            sb.append(getChild(top, fillSpace(top.getName().length() + 2)));
            sb.append(System.lineSeparator());
        }
        return sb.toString();
    }

    private String getChild(Leaf leaf, String prefix) {
        StringBuilder sb = new StringBuilder();
        StringBuilder newPrefix = new StringBuilder();
        newPrefix.append(prefix);
        newPrefix.append(fillSpace(sb.length()));
        String[] children = leaf.getChildren();
        if (children.length == 0) {
            return sb.toString();
        }
        for (int i = 0; i < children.length; i++) {
            Leaf child = leaves.get(children[i]);
            if (i == 0) {
                sb.append("-+-");
            }
            else {
                sb.append(" |-");
            }
            sb.append(child.getName());
            if (i != children.length - 1) {
                sb.append(getChild(child, newPrefix.toString() + " |" + fillSpace(child.getName().length() + 2)));
            } else {
                sb.append(getChild(child, newPrefix.toString() + " " + fillSpace(child.getName().length() + 2)));
            }

            if (i != children.length - 1) {
                sb.append(System.lineSeparator());
                sb.append(newPrefix.toString());
            }
        }
        return sb.toString();
    }

    private String fillSpace(int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append(" ");
        }

        return sb.toString();
    }
}
