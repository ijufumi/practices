package jp.co.everforth.practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {
    public static void main(String... args) {
        if (args.length == 0) {
            System.out.println("引数が指定されていません。");
            System.exit(1);
        }

        Path filePath = null;
        try {
            filePath = Paths.get(args[0]);
        }
        catch (InvalidPathException e) {
            System.out.println("指定されたパスが正しくありません。:" + args[0]);
            e.printStackTrace();
            System.exit(1);
        }

        Tree tree = parseFile(filePath);
        System.out.println(tree);
    }

    private static Tree parseFile(Path filePath) {
        Tree tree = new Tree();
        try (BufferedReader br = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split("/");
                int idx = 0;
                for (int i = 0; i < data.length; i++) {
                    if (data[i].length() == 0) {
                        continue;
                    }
                    Leaf leaf = tree.getLeaf(data[i]);
                    if (leaf == null) {
                        leaf = new Leaf(data[i]);
                    }
                    if (i != data.length - 1) {
                        leaf.addChild(data[i + 1]);
                    }
                    if (idx == 0) {
                        tree.addTopLeaf(leaf);
                    }
                    tree.addLeaf(data[i], leaf);
                    idx++;
                }
            }
        }
        catch (IOException | SecurityException e) {
            System.out.println("ファイルの読み込みに失敗しました。:" + filePath.toString());
            e.printStackTrace();
            System.exit(1);
        }

        return tree;
    }
}


